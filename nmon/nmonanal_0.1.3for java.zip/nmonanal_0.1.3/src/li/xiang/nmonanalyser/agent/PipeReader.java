package li.xiang.nmonanalyser.agent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


public class PipeReader implements Runnable{
	private final HashMap configArea;
	private final ArrayList listeners;
	private final FileReader fileReader;
	private final BufferedReader pipeReader;
	
	public PipeReader(File pipeFile) throws FileNotFoundException{
		configArea = new HashMap();
		listeners = new ArrayList();
		fileReader = new FileReader(pipeFile);
		pipeReader = new BufferedReader(fileReader);
	}
	public void addObserver(ConnectionHandler l){
		synchronized(listeners){
			if(!listeners.contains(l)){
				listeners.add(l);
			}
		}
	}
	public void deleteObserver(ConnectionHandler l){
		synchronized(listeners){
			listeners.remove(l);
		}
	}
	
	public void notifyObservers(String line){
		synchronized(listeners){
			for(int i=0;i<listeners.size();i++){
				((ConnectionHandler)listeners.get(i)).fillBuffer(line);
			}
		}
	}

	protected void fillConfigArea(String line){
		String[] cols = line.split(",");
		ArrayList arrayRef;
		synchronized(configArea){
			if(!configArea.containsKey(cols[0])){	//if there isn't the key yet, add it to hash-map.
				arrayRef = new ArrayList();
				arrayRef.add(line);
				configArea.put(cols[0], arrayRef);
			}else{
				arrayRef = (ArrayList)configArea.get(cols[0]);
				arrayRef.add(line);
			}
		}		
	}
	
	public HashMap getConfigArea() {
		synchronized(configArea){
			return configArea;
		}
	}
	
	public void run() {
		String line = null;
		try {
			while(!Thread.interrupted()&&(line = pipeReader.readLine())!=null){
				String[] cols = line.split(",");
				if(cols[1].matches("T\\d+")){		// ===> Data area(exclude TOP tag).
					notifyObservers(line);
				}else if(cols[0].equals("TOP")){		// ===> Special TOP tag area.
					if(cols.length<3){
						fillConfigArea(line);
					}else if(cols[2].matches("T\\d+")){
						notifyObservers(line);
					}else{
						fillConfigArea(line);
					}
				}else{
					fillConfigArea(line);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
