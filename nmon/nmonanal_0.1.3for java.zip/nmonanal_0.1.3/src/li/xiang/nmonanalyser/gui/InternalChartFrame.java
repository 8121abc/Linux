package li.xiang.nmonanalyser.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import li.xiang.nmonanalyser.CPUTagCharts;
import li.xiang.nmonanalyser.DiskTagCharts;
import li.xiang.nmonanalyser.MEMTagCharts;
import li.xiang.nmonanalyser.NetworkCharts;
import li.xiang.nmonanalyser.NmonAgentLoader;
import li.xiang.nmonanalyser.NmonDataLoader;
import li.xiang.nmonanalyser.NmonFileLoader;
import li.xiang.nmonanalyser.PagingTagCharts;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;


public class InternalChartFrame extends JInternalFrame{
	
	private static final long serialVersionUID = 1L;
	private static int openFrameCount = 0;
	private static final int xOffset = 20,yOffset = 20;
	private NmonDataLoader loader;
	private Thread thread;
	static final String[] rangeList = {"All", "1 min", "5 min", "10 mins", "30 mins",
		"1 hour","2 hours","3 hours","6 hours","12 hours",
		"1 day","2 day"};
	
	private final JTabbedPane tabbedPane ;
	private String platformName;
	
	public InternalChartFrame(String ip,int port){
		super("[ "+ip+":"+port+" ]",
		true, 	//resizeable
		true, 	//closable
		true, 	//maximizable
		true);	//iconifiable
		
		setSize(650,500);
		tabbedPane = new JTabbedPane();
		getContentPane().add(tabbedPane);
		openFrameCount++;
		setLocation(xOffset*openFrameCount,yOffset*openFrameCount);
		
		try {
			loader = new NmonAgentLoader(ip,port);
			
			CPUTagCharts cpuCharts = new CPUTagCharts();
			MEMTagCharts memCharts = new MEMTagCharts();
			PagingTagCharts pagingCharts = new PagingTagCharts();
			DiskTagCharts diskCharts = new DiskTagCharts();
			NetworkCharts netCharts = new NetworkCharts();
			
			loader.addDataObserver(cpuCharts);
			loader.addDataObserver(memCharts);
			loader.addDataObserver(pagingCharts);
			loader.addDataObserver(diskCharts);
			loader.addDataObserver(netCharts);
			
			thread = new Thread(loader);
			thread.start();
			
			while(platformName == null){
				//ArrayList aaaColArray = (ArrayList)fileLoader.getConfigArea().get("AAA");
				ArrayList aaaColArray = (ArrayList)loader.getConfigDataByTag("AAA");
				if(aaaColArray!=null){
					for(int i=0;i<aaaColArray.size();i++){
						String aaaLine = (String)aaaColArray.get(i);
						if(aaaLine.startsWith("AAA,OS,Linux")){
							platformName = aaaLine;
						}else if(aaaLine.startsWith("AAA,AIX")){
							platformName = aaaLine;
						}
					}
				}
				Thread.sleep(100);
			}

			createTabbedPanel(" CPU ",cpuCharts.getCharts());
			createTabbedPanel(" Memory ",memCharts.getCharts());
			if(platformName.startsWith("AAA,AIX")){
				createTabbedPanel(" Paging ",pagingCharts.getCharts());
			}else{
				loader.deleteDataObserver(pagingCharts);
				memCharts = null;
			}
			
			createTabbedPanel(" Disk ",diskCharts.getCharts());
			createTabbedPanel(" Network ", netCharts.getCharts());			
			
			this.setVisible(true);
			
		} catch (UnknownHostException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public InternalChartFrame(String uri){
			super(uri,
			true, 	//resizeable
			true, 	//closable
			true, 	//maximizable
			true);	//iconifiable

		setSize(650,500);
		tabbedPane = new JTabbedPane();
		getContentPane().add(tabbedPane);
		openFrameCount++;
		setLocation(xOffset*openFrameCount,yOffset*openFrameCount);
		try {
			loader = new NmonFileLoader(uri);
			CPUTagCharts cpuCharts = new CPUTagCharts();
			MEMTagCharts memCharts = new MEMTagCharts();
			PagingTagCharts pagingCharts = new PagingTagCharts();
			DiskTagCharts diskCharts = new DiskTagCharts();
			NetworkCharts netCharts = new NetworkCharts();
			
			loader.addDataObserver(cpuCharts);
			loader.addDataObserver(memCharts);
			loader.addDataObserver(pagingCharts);
			loader.addDataObserver(diskCharts);
			loader.addDataObserver(netCharts);
			
			thread = new Thread(loader);
			thread.start();
			while(platformName == null){
				//ArrayList aaaColArray = (ArrayList)fileLoader.getConfigArea().get("AAA");
				ArrayList aaaColArray = (ArrayList)loader.getConfigDataByTag("AAA");
				if(aaaColArray!=null){
					for(int i=0;i<aaaColArray.size();i++){
						String aaaLine = (String)aaaColArray.get(i);
						if(aaaLine.startsWith("AAA,OS,Linux")){
							platformName = aaaLine;
						}else if(aaaLine.startsWith("AAA,AIX")){
							platformName = aaaLine;
						}
					}
				}
				Thread.sleep(200);
			}
			createTabbedPanel(" CPU ",cpuCharts.getCharts());
			createTabbedPanel(" Memory ",memCharts.getCharts());
			
			if(platformName.startsWith("AAA,AIX")){
				createTabbedPanel(" Paging ",pagingCharts.getCharts());
			}else{
				loader.deleteDataObserver(memCharts);
			}
			createTabbedPanel(" Disk ",diskCharts.getCharts());
			createTabbedPanel(" Network ", netCharts.getCharts());
			
			this.setVisible(true);
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this,e.toString(),"File: "+uri+" not found.",JOptionPane.ERROR_MESSAGE);
		} catch (InterruptedException e) {
			//e.printStackTrace();
		}
	}

	public void createTabbedPanel(String tabName,final JFreeChart[] charts){
		JPanel rootPanel = new JPanel();
		rootPanel.setLayout(new BoxLayout(rootPanel, BoxLayout.Y_AXIS));
		// ======> Range Panel <========
		JPanel rangePanel = new JPanel();
		JLabel timeRangeLabel = new JLabel("  Time Range:  ");
		timeRangeLabel.setAlignmentX(CENTER_ALIGNMENT);
		JComboBox  timeRangeCombBox = new JComboBox(rangeList);
		timeRangeCombBox.setAlignmentX(CENTER_ALIGNMENT);
		//JLabel loaderStatus = new JLabel("Loader Status:");
		//loaderStatus.setAlignmentX(CENTER_ALIGNMENT);
		timeRangeCombBox.addActionListener(new ActionListener(){	// CombBox 's action handler ...
			public void actionPerformed(ActionEvent event) {
				JComboBox cb = (JComboBox)event.getSource();
				String selected = (String) cb.getSelectedItem();
				double selectedRange = selectedTimeRange(selected);
				if(selectedRange>0){
					for(int i=0;i<charts.length;i++){
						XYPlot xyplot = charts[i].getXYPlot();

						ValueAxis valueaxis = xyplot.getDomainAxis();
						valueaxis.setAutoRange(true);
						valueaxis.setFixedAutoRange(selectedRange);
					}
				}else{
					for(int i=0;i<charts.length;i++){
						XYPlot xyplot = charts[i].getXYPlot();

						ValueAxis valueaxis = xyplot.getDomainAxis();
						valueaxis.setAutoRange(true);
						valueaxis.setFixedAutoRange(0D);
					}
				}
			}
			public double selectedTimeRange(String selected){
				String[] data = selected.split(" ");
				if(data.length != 2){
					return -1D;
				}else{

					int num = Integer.parseInt(data[0]);
					if(data[1].startsWith("min")){
						return num*60000D;
					}else if(data[1].startsWith("hour")){
						return num*60*60000D;
					}else if(data[1].startsWith("day")){
						return num*24*60*60000D;
					}else{
						return -1D;
					}
				}
			}
		});
		rangePanel.setSize(new Dimension(650,25));
		rangePanel.add(timeRangeLabel);
		rangePanel.add(timeRangeCombBox);
		// ======> Charts Panel <========
		JPanel chartPanel = new JPanel();
		chartPanel.setPreferredSize(new Dimension(650,1600));
		GridLayout chartPanelLayout = new GridLayout(0,1);
		chartPanelLayout.setHgap(20);
		chartPanelLayout.setVgap(20);
		chartPanel.setLayout(chartPanelLayout);
		for(int i=0;i<charts.length;i++){
			ChartPanel chart = new ChartPanel(charts[i]);
			chartPanel.add(chart);
		}
		rootPanel.add(rangePanel);
		rootPanel.add(chartPanel);
		tabbedPane.add(tabName,rootPanel);
	}

	public void dispose(){
		thread.interrupt();
		loader.close();
		super.dispose();
	}
}