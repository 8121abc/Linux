package li.xiang.nmonanalyser.agent;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ResourceBundle;

public class AgentConfiguration {
	private static AgentConfiguration config;
	private boolean _debugEnable = true;
	private String _pipeURI = "/tmp/nmonnamedpipe";
	private int _maxConn = 10;
	private int _port = 8187;
	private AgentConfiguration(){
		ResourceBundle bundle = ResourceBundle.getBundle("li.xiang.nmonanalyser.agent.agent");
		
		String pipeURI = bundle.getString("agent.pipelocation");
		if(pipeURI!=null){
			_pipeURI = pipeURI;
		}
		String strMaxConn = bundle.getString("agent.maxconnection");
		String strPort = bundle.getString("agent.port");
		int maxConn = Integer.parseInt(strMaxConn);
		int port = Integer.parseInt(strPort);
		
		if(maxConn > 0){
			_maxConn = maxConn;
		}
		if(port > 0){
			_port = port;
		}
	}
	public String getPipeURI(){
		return _pipeURI;
	}
	public int getMaxConnection(){
		return _maxConn;
	}
	public int getPort(){
		return _port;
	}
	private void setDebugable(boolean debug){
		_debugEnable = debug;
	}
	public static AgentConfiguration getConfig(boolean debug){
		if(config == null){
			config = new AgentConfiguration();
		}
		config.setDebugable(debug);
		return config;
	}
	public void debug(String msg){
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if(_debugEnable){
			System.out.println("["+formatter.format(calendar.getTime())+"]: "+msg);
		}
	}
}
