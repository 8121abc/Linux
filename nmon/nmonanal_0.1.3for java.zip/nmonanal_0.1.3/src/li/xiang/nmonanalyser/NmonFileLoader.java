package li.xiang.nmonanalyser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class NmonFileLoader implements NmonDataLoader,Runnable {
	private final HashMap configArea ;
	private final ArrayList listeners;
	private final FileReader fileReader ;
	private final BufferedReader reader;
	private final HashMap pointOfDate;
	private String fileLocation;
	
	public NmonFileLoader(String uri) throws FileNotFoundException{
		
		configArea=new HashMap();
		pointOfDate = new HashMap();
		listeners = new ArrayList();
		fileLocation = uri;
		fileReader = new FileReader(fileLocation);
		reader = new BufferedReader(fileReader);
		
	}
	
	public void addDataObserver(NmonDataListener l) {
		synchronized(listeners){
			if(!listeners.contains(l)){
				listeners.add(l);
			}
		}
	}
	
	public void deleteDataObserver(NmonDataListener l) {
		synchronized(listeners){
			listeners.remove(l);
		}
	}

	public void fireOnDataLoad(String line) {
		LoadEventData eventData = new LoadEventData(this,line);
		synchronized(listeners){
			for(int i=0;i<listeners.size();i++){
				((NmonDataListener)listeners.get(i)).onDataLoad(eventData);
			}
		}
	}

	public HashMap getAllConfigData() {
		synchronized(configArea){
			return configArea;
		}
	}
	
	public ArrayList getConfigDataByTag(String tag){
		synchronized(configArea){
			ArrayList tagData = (ArrayList)configArea.get(tag); 
			return tagData;
		}
	}
	
	protected void fillConfigArea(String line){
		String[] cols = line.split(",");
		ArrayList arrayRef;
		synchronized(configArea){
			if(!configArea.containsKey(cols[0])){	//if there isn't the key yet, add it to hash-map.
				arrayRef = new ArrayList();
				arrayRef.add(line);
				configArea.put(cols[0], arrayRef);
			}else{
				arrayRef = (ArrayList)configArea.get(cols[0]);
				arrayRef.add(line);
			}
		}
	}
	
	public void close(){
		
		listeners.clear();
		try {
			reader.close();
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected String getPointOfDate(String point){
		synchronized(pointOfDate){
			return (String)pointOfDate.get(point);
		}
	}
	
	public void run(){
		String line = null;
		try {
			while((!Thread.interrupted())&&(line =reader.readLine())!=null){
				String[] cols = line.split(",");
				if(cols[0].equals("ZZZZ")){				// ===> Special ZZZZ tag area.
					String strDate = cols[2]+"@"+cols[3];
					synchronized(pointOfDate){
						pointOfDate.put(cols[1], strDate);
					}
				}else if(cols[1].matches("T\\d+")){		// ===> Data area(exclude TOP tag).
					String timestamp = getPointOfDate(cols[1]);
					String newLine = line.replaceFirst(cols[1],timestamp);
					fireOnDataLoad(newLine);
				}else if(cols[0].equals("TOP")){		// ===> Special TOP tag area.
					if(cols.length<3){
						fillConfigArea(line);
					}else if(cols[2].matches("T\\d+")){
						String timestamp = getPointOfDate(cols[2]);
						String newLine = line.replaceFirst(cols[2],timestamp);
						fireOnDataLoad(newLine);
					}else{
						fillConfigArea(line);
					}
				}else{									// ===> Configuration area(exclude TOP tag).
					fillConfigArea(line);
				}
			}
		} catch (Exception e) {	
			System.exit(-1);
		}
	}

	public static void main(String[] args) throws FileNotFoundException{
		NmonFileLoader loader = new NmonFileLoader("C:\\Users\\LiXiang\\Desktop\\GC\\adb00_root_100114_1000.nmon");
		//NmonFileLoader loader = new NmonFileLoader("C:\\Users\\LiXiang\\Desktop\\GC\\lixiang_100127_1623.nmon");
		//NmonFileLoader loader = new NmonFileLoader("/media/LIXIANG/adb00_root_100114_1000.nmon");
		CPUTagCharts cpuCharts = new CPUTagCharts();
		MEMTagCharts memCharts = new MEMTagCharts();
		
		loader.addDataObserver(cpuCharts);
		loader.addDataObserver(memCharts);
		
		Thread loaderThread = new Thread(loader);
		loaderThread.run();
	}

}
