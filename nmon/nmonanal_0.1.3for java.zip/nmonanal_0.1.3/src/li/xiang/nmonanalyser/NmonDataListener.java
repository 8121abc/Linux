package li.xiang.nmonanalyser;

public interface NmonDataListener {
	public void onDataLoad(LoadEventData e);
}
