package li.xiang.nmonanalyser;

import java.awt.BasicStroke;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class DiskTagCharts implements NmonDataListener{
	private ArrayList aaaColArray;
	private ArrayList xferColArray;
	private ArrayList readColArray;
	private ArrayList writeColArray;
	private int platformName = -1;//-1, unknown platform; 0, AIX platform; 1, LINUX platform.
	private String xferColName;
	private String readColName;
	private String writeColName;
	private final SimpleDateFormat formatter;
	private final TimeSeriesCollection xferDataSet;
	private final TimeSeriesCollection readDetailDataSet;
	private final TimeSeriesCollection readTotalDataSet;
	private final TimeSeriesCollection writeDetailDataSet;
	private final TimeSeriesCollection writeTotalDataSet;
	private final TimeSeries xferSeries;
	private final TimeSeries readTotalSeries;
	private final TimeSeries writeTotalSeries;
	private final JFreeChart[] charts;
	private final JFreeChart diskIOSummary;
	private final JFreeChart readDetail;
	private final JFreeChart writeDetail;
	
	public DiskTagCharts(){
		formatter = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
		xferDataSet = new TimeSeriesCollection();
		readDetailDataSet = new TimeSeriesCollection();
		readTotalDataSet = new TimeSeriesCollection();
		writeDetailDataSet = new TimeSeriesCollection();
		writeTotalDataSet = new TimeSeriesCollection();
		xferSeries = new TimeSeries("IO/Sec");
		readTotalSeries = new TimeSeries("Read Total");
		writeTotalSeries = new TimeSeries("Write Total");
		
		xferDataSet.addSeries(xferSeries);
		readTotalDataSet.addSeries(readTotalSeries);
		writeTotalDataSet.addSeries(writeTotalSeries);
		
		ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
		diskIOSummary = ChartFactory.createTimeSeriesChart(
				"Disk I/O summary",
				"",
				"[ io/sec ]",
				xferDataSet,
				true,
				false,
				false);
		diskIOSummary.getTitle().setFont(new Font("Serif",Font.PLAIN,16));
		XYPlot xyplot1 = diskIOSummary.getXYPlot();
		xyplot1.setForegroundAlpha(0.7f);
		xyplot1.getDomainAxis().setLowerMargin(0.0D);
		xyplot1.getDomainAxis().setUpperMargin(0.0D);

		XYItemRenderer xyplot1Renderer1 = xyplot1.getRenderer(0);
		xyplot1Renderer1.setSeriesStroke(0,new BasicStroke(	1.9f));
		
		XYItemRenderer xyplot1Renderer2 = new XYAreaRenderer();
		ValueAxis axis2 = new NumberAxis("[ KB/Sec ]");
		xyplot1.setDataset(1, readTotalDataSet);
		xyplot1.setRangeAxis(1,axis2);
		xyplot1.setRenderer(1, xyplot1Renderer2);
		xyplot1.mapDatasetToRangeAxis(1, 1);
		
		XYItemRenderer xyplot1renderer3 = new XYAreaRenderer();
		xyplot1.setDataset(2, writeTotalDataSet);
		xyplot1.setRenderer(2,xyplot1renderer3);
		xyplot1.mapDatasetToRangeAxis(2, 1);
		
		readDetail = ChartFactory.createTimeSeriesChart(
				"Disk Read ",
				"",
				"[ KB/Sec ]",
				readDetailDataSet,
				true,
				false,
				false);
		readDetail.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot2 = readDetail.getXYPlot();
		xyplot2.getDomainAxis().setLowerMargin(0.0);
		xyplot2.getDomainAxis().setUpperMargin(0.0);
		xyplot2.setForegroundAlpha(0.7f);
		
		writeDetail = ChartFactory.createTimeSeriesChart(
				"Disk Write ",
				"",
				"[ KB/sec ]",
				writeDetailDataSet,
				true,
				false,
				false);
		writeDetail.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot3 = writeDetail.getXYPlot();
		xyplot3.getDomainAxis().setLowerMargin(0.0);
		xyplot3.getDomainAxis().setUpperMargin(0.0);
		xyplot3.setForegroundAlpha(0.7f);
		
		charts = new JFreeChart[3];
		charts[0] = diskIOSummary;
		charts[1] = readDetail;
		charts[2] = writeDetail;
	}
	
	public JFreeChart[] getCharts(){
		synchronized(charts){
			return charts;
		}
	}
	
	public void onDataLoad(LoadEventData e) {
		String line = e.getEventData();
		String[] cols = line.split(",");
		NmonDataLoader source = e.getEventSource();
		
		if(platformName == -1){
			aaaColArray = (ArrayList)source.getConfigDataByTag("AAA");
			if(aaaColArray!=null){
				for(int i=0;i<aaaColArray.size();i++){
					String aaaLine = (String)aaaColArray.get(i);
					if(aaaLine.startsWith("AAA,OS,Linux")){
						platformName = 1;
					}else if(aaaLine.startsWith("AAA,AIX")){
						platformName = 0;
					}
				}
			}else{
				return;
			}
		}else if(xferColName == null){
			xferColArray = (ArrayList)source.getConfigDataByTag("DISKXFER");
			if((xferColArray!=null)){
				xferColName = (String)xferColArray.get(0);
			}else{
				return;
			}
		}else if(readColName == null){
			readColArray = (ArrayList)source.getConfigDataByTag("DISKREAD");
			if(readColArray!=null){
				readColName = (String)readColArray.get(0);
			}else{
				return;
			}
		}else if(writeColName == null){
			writeColArray = (ArrayList)source.getConfigDataByTag("DISKWRITE");
			if(writeColArray!=null){
				writeColName = (String)writeColArray.get(0);
			}else{
				return;
			}
		}else if(platformName == 1){
			if(cols[0].equals("DISKXFER")){
				String[] names = xferColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double xferVal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("[sh]d[a-z]")){
							xferVal += Double.parseDouble(cols[i]);
						}
					}
					synchronized(diskIOSummary){
						xferSeries.add(dateItem,xferVal);
					}
					
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				}
			}else if(cols[0].equals("DISKREAD")){
				String[] names = readColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double readTotal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("[sh]d[a-z]")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(readDetail){
								TimeSeries seriesRef = readDetailDataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									readDetailDataSet.addSeries(seriesRef);
									int seriesCount = readDetailDataSet.getSeriesCount();
									XYPlot xyplot = readDetail.getXYPlot();
									XYItemRenderer xyplotRenderer = xyplot.getRenderer();
									for(int j=0;j<seriesCount;j++){
										xyplotRenderer.setSeriesStroke(j, new BasicStroke(1.9f));
									}
								}
								seriesRef.add(dateItem,theVal);
							}
							readTotal += theVal;
						}
					}
					synchronized(diskIOSummary){
						readTotalSeries.add(dateItem,readTotal);
					}
				} catch (ParseException e1) {

				}
			}else if(cols[0].equals("DISKWRITE")){
				String[] names = writeColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double writeTotal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("[sh]d[a-z]")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(writeDetail){
								TimeSeries seriesRef = writeDetailDataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									writeDetailDataSet.addSeries(seriesRef);
									int seriesCount = writeDetailDataSet.getSeriesCount();
									XYPlot xyplot = writeDetail.getXYPlot();
									XYItemRenderer xyplotRenderer = xyplot.getRenderer();
									for(int j=0;j<seriesCount;j++){
										xyplotRenderer.setSeriesStroke(j, new BasicStroke(1.9f));
									}
								}
								seriesRef.add(dateItem,theVal);
							}
							writeTotal += theVal;
						}
					}
					synchronized(diskIOSummary){
						writeTotalSeries.add(dateItem,writeTotal);
					}
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				}
			}
		}else if(platformName == 0){
			if(cols[0].equals("DISKXFER")){
				String[] names = xferColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double xferVal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("powerpath\\d+|hdisk\\d+|vpath\\d+")){
							xferVal += Double.parseDouble(cols[i]);
						}
					}
					synchronized(diskIOSummary){
						xferSeries.add(dateItem,xferVal);
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : ==");
					System.out.println(line);
					System.exit(-1);
				}
			}else if(cols[0].equals("DISKREAD")){
				String[] names = readColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double readTotal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("powerpath\\d+|hdisk\\d+|vpath\\d+")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(readDetail){
								TimeSeries seriesRef = readDetailDataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									readDetailDataSet.addSeries(seriesRef);
									int seriesCount = readDetailDataSet.getSeriesCount();
									XYPlot xyplot = readDetail.getXYPlot();
									XYItemRenderer xyplotRenderer = xyplot.getRenderer();
									for(int j=0;j<seriesCount;j++){
										xyplotRenderer.setSeriesStroke(j, new BasicStroke(1.9f));
									}
								}
								seriesRef.add(dateItem,theVal);
							}
							readTotal += theVal;
						}
					}
					synchronized(diskIOSummary){
						readTotalSeries.add(dateItem,readTotal);
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : ==");
					System.out.println(line);
					System.exit(-1);
				}
				
			}else if(cols[0].equals("DISKWRITE")){
				String[] names = writeColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double writeTotal = 0.0D;
					for(int i=2;i<names.length;i++){
						if(names[i].matches("powerpath\\d+|hdisk\\d+|vpath\\d+")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(writeDetail){
								TimeSeries seriesRef = writeDetailDataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									writeDetailDataSet.addSeries(seriesRef);
									int seriesCount = writeDetailDataSet.getSeriesCount();
									XYPlot xyplot = writeDetail.getXYPlot(); 
									XYItemRenderer xyplotRenderer = xyplot.getRenderer();
									for(int j=0;j<seriesCount;j++){
										xyplotRenderer.setSeriesStroke(j, new BasicStroke(1.9f));
									}
								}
								seriesRef.add(dateItem,theVal);
							}
							writeTotal += theVal;
						}
					}
					synchronized(diskIOSummary){
						writeTotalSeries.add(dateItem,writeTotal);
					}
				} catch (ParseException e1) {
					//e1.printStackTrace();
				}
			}
		}
	}

}
