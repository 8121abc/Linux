package li.xiang.nmonanalyser;

import java.awt.Font;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class PagingTagCharts implements NmonDataListener{
	
	private ArrayList aaaColArray;
	private int platformName = -1; //-1, unknown platform; 0, AIX platform; 1, LINUX platform.
	private String pagingColName;
	private ArrayList pagingColArray;
	private final SimpleDateFormat formatter;
	private final TimeSeriesCollection pgsDataSet;
	private final TimeSeries pgsinSeries;
	private final TimeSeries pgsoutSeries;
	private final TimeSeriesCollection pgDataSet;
	private final TimeSeries pginSeries;
	private final TimeSeries pgoutSeries;
	private final JFreeChart[] charts;
	private final JFreeChart pgChart;
	private final JFreeChart pgsChart;
	
	private final DecimalFormat deciFormat ;
	
	public PagingTagCharts(){
		
		formatter = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
		deciFormat = new DecimalFormat("#0.00");
		
		pgsDataSet = new TimeSeriesCollection();
		pgsinSeries = new TimeSeries(" pgs-in ");
		pgsoutSeries = new TimeSeries(" pgs-out(-ve) ");
		pgsDataSet.addSeries(pgsinSeries);
		pgsDataSet.addSeries(pgsoutSeries);
		
		pgDataSet = new TimeSeriesCollection();
		pginSeries = new TimeSeries(" pg-in ");
		pgoutSeries = new TimeSeries(" pg-out(-ve) ");
		pgDataSet.addSeries(pginSeries);
		pgDataSet.addSeries(pgoutSeries);
		
		
		ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
		pgsChart = ChartFactory.createXYAreaChart(
				" Page in/out ",
				"",
				"",
				pgsDataSet,
				PlotOrientation.VERTICAL,
				true,
				false,
				false);
		pgsChart.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot1 = pgsChart.getXYPlot();
		DateAxis domainAxis1 = new DateAxis("");
		domainAxis1.setLowerMargin(0.0);
		domainAxis1.setUpperMargin(0.0);
		xyplot1.setDomainAxis(domainAxis1);
		xyplot1.setForegroundAlpha(0.6f);
		
		NumberAxis rangeAxis = (NumberAxis) xyplot1.getRangeAxis();
		rangeAxis.setNumberFormatOverride(deciFormat);

		pgChart = ChartFactory.createXYAreaChart(
				" Page in/out (include filesystem) ",
				"",
				"",
				pgDataSet,
				PlotOrientation.VERTICAL,
				true,
				false,
				false);
		
		pgChart.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot2 = pgChart.getXYPlot();
		DateAxis domainAxis2 = new DateAxis("");
		domainAxis2.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:mm:ss",Locale.US));
		domainAxis2.setLowerMargin(0.0);
		domainAxis2.setUpperMargin(0.0);
		xyplot2.setDomainAxis(domainAxis2);
		xyplot2.setForegroundAlpha(0.6f);

		charts = new JFreeChart[2];
		charts[0] = pgsChart;
		charts[1] = pgChart;
	}
	
	public void onDataLoad(LoadEventData e) {
		String line = e.getEventData();
		String[] cols = line.split(",");
		NmonDataLoader source = e.getEventSource();
		//Parse AAA tag's data, get the platform information.
		if(platformName == -1){
			//aaaColArray = (ArrayList)source.getConfigArea().get("AAA");
			aaaColArray = (ArrayList)source.getConfigDataByTag("AAA");
			if(aaaColArray!=null){
				for(int i=0;i<aaaColArray.size();i++){
					String aaaLine = (String)aaaColArray.get(i);
					if(aaaLine.startsWith("AAA,OS,Linux")){
						platformName = 1;
					}else if(aaaLine.startsWith("AAA,AIX")){
						platformName = 0;
					}
				}
			}else{
				return ;
			}
		}else if((platformName == 0)&&(pagingColName == null)){
			//pagingColArray = (ArrayList)source.getConfigArea().get("PAGE");
			pagingColArray = (ArrayList)source.getConfigDataByTag("PAGE");
			if((pagingColArray!=null)){
				pagingColName = (String)pagingColArray.get(0);
			}else{
				return ;
			}
		}
		if(platformName == 0){
			if(cols[0].equals("PAGE")){
				String[] names = pagingColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					for(int i=2;i<names.length;i++){ //Get "pgin", "pgout", "pgsin", "pgsout" column's data.
						if(names[i].equals("pgin")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(pgDataSet){
								pginSeries.add(dateItem,theVal);
							}
						}else if(names[i].equals("pgout")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(pgDataSet){
								pgoutSeries.add(dateItem,-theVal);
							}
						}else if(names[i].equals("pgsin")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(pgsDataSet){
								pgsinSeries.add(dateItem,theVal);
							}
						}else if(names[i].endsWith("pgsout")){
							double theVal = Double.parseDouble(cols[i]);
							synchronized(pgsDataSet){
								pgsoutSeries.add(dateItem,-theVal);
							}
						}
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : "+"==");
					System.out.println(line);
					System.exit(-1);
					
				}
			}
		}
	}
	
	public JFreeChart[] getCharts(){
		synchronized(charts){
			return charts;
		}
	}
	
}
