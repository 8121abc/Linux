package li.xiang.nmonanalyser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;

public class NmonAgentLoader implements Runnable,NmonDataLoader{
	private final HashMap configArea ;
	private final ArrayList listeners;
	private final Socket connection;
	private final BufferedReader reader ;
	private final PrintWriter sender ;
	private HashMap pointOfDate;
	
	public NmonAgentLoader(String ip,int port) throws UnknownHostException, IOException{
		connection = new Socket(ip,port);
		reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		sender = new PrintWriter(connection.getOutputStream());
		
		sender.println("CONFIGDATA@ALL");
		sender.flush();
		
		configArea = new HashMap();
		pointOfDate = new HashMap();
		listeners = new ArrayList();
		
	}
	
	protected String getPointOfDate(String point){
		synchronized(pointOfDate){
			return (String)pointOfDate.get(point);
		}
	}
	
	public void run() {
		while(!Thread.interrupted()&&connection.isConnected()){
			try {
				String line = null;
				while((line=reader.readLine())!=null){
					String[] cols = line.split(",");
					if(cols[0].equals("ZZZZ")){				// ===> Special ZZZZ tag area.
						String strDate = cols[2]+"@"+cols[3];
						synchronized(pointOfDate){
							pointOfDate.put(cols[1], strDate);
						}
					}else if(cols[1].matches("T\\d+")){
						String timestamp = getPointOfDate(cols[1]);
						String newLine = line.replaceFirst(cols[1],timestamp);
						fireOnDataLoad(newLine);
						
					}else if(cols[0].equals("TOP")){
						if(cols.length<3){
							fillConfigArea(line);
						}else if(cols[2].matches("T\\d+")){
							String timestamp = getPointOfDate(cols[1]);
							String newLine = line.replaceFirst(cols[1],timestamp);
							fireOnDataLoad(newLine);
						}else{
							fillConfigArea(line);
						}
					}else{
						fillConfigArea(line);
					}
				}
			} catch (IOException e) {
				//System.out.println("NmonAgentLoader!:\n"+e.toString());
				//System.exit(-1);
			}
		}
	}

	public void fillConfigArea(String line){
		String[] cols = line.split(",");
		ArrayList arrayRef;
		synchronized(configArea){
			if(!configArea.containsKey(cols[0])){
				arrayRef = new ArrayList();
				configArea.put(cols[0], arrayRef);
				arrayRef.add(line);
			}else{
				arrayRef = (ArrayList)configArea.get(cols[0]);
				if(!arrayRef.contains(line)){
					arrayRef.add(line);
				}
			}
		}
	}
	
	public void addDataObserver(NmonDataListener l) {
		synchronized(listeners){
			if(!listeners.contains(l)){
				listeners.add(l);
			}
		}		
	}

	public void deleteDataObserver(NmonDataListener l) {
		synchronized(listeners){
			listeners.remove(l);
		}		
	}

	public void fireOnDataLoad(String line) {
		LoadEventData eventData = new LoadEventData(this,line);
		synchronized(listeners){
			for(int i=0;i<listeners.size();i++){
				((NmonDataListener)listeners.get(i)).onDataLoad(eventData);
			}
		}
	}
	
	public ArrayList getConfigDataByTag(String tag) {
		
		synchronized(configArea){
			ArrayList tagData = (ArrayList)configArea.get(tag); 
			if(tagData!=null){
				return tagData;
			}else{
				sender.println("CONFIGDATA@"+tag);
				sender.flush();
				return null;
			}
		}
	}
	
	public HashMap getAllConfigData() {
		synchronized(configArea){
			sender.println("CONFIGDATA@ALL");
			sender.flush();
			return configArea;
		}
	}
	
	public void close(){
		listeners.clear();
		try {
			connection.close();
		} catch (IOException e) {
			//e.printStackTrace();
		}
	}

}
