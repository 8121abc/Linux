package li.xiang.nmonanalyser;

public class LoadEventData {
	private final NmonDataLoader source;
	private final String line;
	public LoadEventData(NmonDataLoader source,String line){
		this.source = source;
		this.line = line;
	}
	public synchronized NmonDataLoader getEventSource(){
		return source;
	}
	public synchronized String getEventData(){
		return line;
	}
}
