package li.xiang.nmonanalyser.gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class MainFrame {
	
	public static final String build = "20140225-001";
	
	private static void createAndShowGUI() {
		final JFrame appFrame = new JFrame();
		final JDesktopPane mainFrameDesktop = new JDesktopPane();
		final JMenuBar mainMenuBar = new JMenuBar();
		final JMenu file = new JMenu("  Data Loader  ");
		final JMenu tools = new JMenu("  Tools  ");
		final JMenu help = new JMenu("  Help  ");
		final JMenuItem openFile = new JMenuItem(" From *.nmon file ");
		final JMenuItem openConn = new JMenuItem(" From agent... ");
		final JMenuItem quit = new JMenuItem(" Quit ");
		final JMenuItem about = new JMenuItem(" About ");
		// ===> Inner class, MainFrame's action handler. <==
		class AppActionListener implements ActionListener{	
			public void actionPerformed(ActionEvent e) {
				String cmd = e.getActionCommand();
				if(cmd.equals("Exit")){
					System.exit(0);
				}else if(cmd.equals("ConnAgent")){
					AgentSelectFrame.showDiaglog(appFrame,mainFrameDesktop,"");
					String targetIP = AgentSelectFrame.getTargetIP();
					int targetPort = AgentSelectFrame.getTargetPort();
					if((targetIP!=null)&&(targetPort>0)){
						InternalChartFrame in = new InternalChartFrame(targetIP,targetPort);
						mainFrameDesktop.add(in);
					}
				}else if(cmd.equals("OpenFile")){
					FileDialog fileDialog = new FileDialog(appFrame,"Select a Nmon File.",FileDialog.LOAD);
					fileDialog.setLocationRelativeTo(appFrame);
					fileDialog.setVisible(true);
					String fileName = fileDialog.getFile();
					if(null == fileName)
						return ;
					String fullPath = fileDialog.getDirectory()+fileName;
					InternalChartFrame in = new InternalChartFrame(fullPath);
					mainFrameDesktop.add(in);
				}else if(cmd.equals("About")){
					String aboutme = "<html><center><b>System performance monitor for LINUX & AIX.</b><br><br>"+
						"<i>Build : "+build+"</i><br><br>"+
						"<i>Bug report to: <a href=\"mailto:lee.xiang@hotmail.com\">lee.xiang@hotmail.com</a></i></center></html>";
					
					JOptionPane.showMessageDialog(appFrame,aboutme,"About me ...",JOptionPane.INFORMATION_MESSAGE);

				}
			}
		}
		
		AppActionListener actionListener = new AppActionListener();
		appFrame.setTitle("System Performance Monitor for LINUX & AIX");
		openFile.setActionCommand("OpenFile");
		openFile.addActionListener(actionListener);
		openConn.setActionCommand("ConnAgent");
		openConn.addActionListener(actionListener);
		quit.addActionListener(actionListener);
		quit.setActionCommand("Exit");
		about.addActionListener(actionListener);
		about.setActionCommand("About");
		file.add(openFile);
		file.add(openConn);
		file.addSeparator();
		file.add(quit);	
		help.add(about);
		mainMenuBar.add(file);
		mainMenuBar.add(tools);
		mainMenuBar.add(help);
		Container rootContain = appFrame.getContentPane();
		rootContain.setLayout(new BorderLayout());
		rootContain.add(mainFrameDesktop,BorderLayout.CENTER);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		mainFrameDesktop.setPreferredSize(new Dimension(screenSize.width-120,screenSize.height-80));
		appFrame.setSize(new Dimension(screenSize.width-120,screenSize.height-80));
		appFrame.setLocationRelativeTo(null);
		appFrame.setJMenuBar(mainMenuBar);
		appFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		appFrame.setVisible(true);

	}
	
	public static void main(String[] args){
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

}
