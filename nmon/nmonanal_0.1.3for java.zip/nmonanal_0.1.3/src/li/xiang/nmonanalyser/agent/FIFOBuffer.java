package li.xiang.nmonanalyser.agent;

import java.util.LinkedList;

public class FIFOBuffer {
	private final LinkedList buffer ;
	private final static int size = 102400;
	public FIFOBuffer(){
		buffer = new LinkedList();
	}
	public void put(String line){
		synchronized(buffer){
			if(buffer.size()<size){
				buffer.addFirst(line);
				buffer.notify();
			}else{ 
				buffer.clear();
			}
		}
	}
	public void clearAll(){
		buffer.clear();
	}
	public String get() throws InterruptedException{
		synchronized (buffer){
			while(buffer.isEmpty()){
				buffer.wait();
			}
			return (String) buffer.removeLast();
		}
	}
	public boolean isEmpty(){
		synchronized(buffer){
			return buffer.isEmpty();
		}
	}
	public int size(){
		return buffer.size();
	}
}
