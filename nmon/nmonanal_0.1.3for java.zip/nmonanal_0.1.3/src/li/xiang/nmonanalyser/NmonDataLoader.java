package li.xiang.nmonanalyser;

import java.util.ArrayList;
import java.util.HashMap;

public interface NmonDataLoader extends Runnable{
	
	public void addDataObserver(NmonDataListener l);
	public void deleteDataObserver(NmonDataListener l);
	public void fireOnDataLoad(String line);
	
	public HashMap getAllConfigData();
	public ArrayList getConfigDataByTag(String tag);
	
	public void close();
	
}
