package li.xiang.nmonanalyser;

import java.awt.BasicStroke;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class NetworkCharts implements NmonDataListener{
	private final SimpleDateFormat formatter;
	private String netColName;
	private ArrayList netColArray;
	private final TimeSeriesCollection netDetailDataSet;
	private final TimeSeriesCollection netTotalDataSet;
	private final TimeSeries readTotalSeries;
	private final TimeSeries writeTotalSeries;
	private final JFreeChart[] charts;
	private final JFreeChart netTotal;
	private final JFreeChart netDetail;
	
	public NetworkCharts(){
		formatter = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
		netDetailDataSet = new TimeSeriesCollection();
		netTotalDataSet = new TimeSeriesCollection();
		readTotalSeries = new TimeSeries(" Total-In ");
		writeTotalSeries = new TimeSeries(" Total-Out(-ve) ");
		
		netTotalDataSet.addSeries(readTotalSeries);
		netTotalDataSet.addSeries(writeTotalSeries);
		
		netTotal = ChartFactory.createXYAreaChart(
				"Network I/O - Total", 
				"",
				"[ KB/sec ]", 
				netTotalDataSet,
				PlotOrientation.VERTICAL, 
				true,
				false,
				false);
		netTotal.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot1 = netTotal.getXYPlot(); 
		DateAxis domainAxis = new DateAxis("");
		domainAxis.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:ss",Locale.US));
		domainAxis.setLowerMargin(0.0);
		domainAxis.setUpperMargin(0.0);
		xyplot1.setDomainAxis(domainAxis);
		xyplot1.setForegroundAlpha(0.7f);
		
		netDetail = ChartFactory.createTimeSeriesChart(
				"Network I/O - Detail",
				"", 
				"[ KB/sec ]",
				netDetailDataSet,
				true,
				false,
				false);
		netDetail.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot2 = netDetail.getXYPlot(); 
		xyplot2.getDomainAxis().setLowerMargin(0.0);
		xyplot2.getDomainAxis().setUpperMargin(0.0);
		
		charts = new JFreeChart[2];
		charts[0] = netTotal;
		charts[1] = netDetail;
		
	}
	
	public JFreeChart[] getCharts(){
		synchronized(charts){
			return charts;
		}
	}
	
	public void onDataLoad(LoadEventData e) {
		String line = e.getEventData();
		String[] cols = line.split(",");
		NmonDataLoader source = e.getEventSource();
		if(netColName == null){
			netColArray = (ArrayList)source.getConfigDataByTag("NET");
			if(netColArray!=null){
				netColName = (String)netColArray.get(0);
			}else{
				return;
			}
		}
		if(cols[0].equals("NET")){
			String[] names = netColName.split(",");
			try {
				Date timestamp = formatter.parse(cols[1]);
				Millisecond dateItem = new Millisecond(timestamp);
				double netReadTotal = 0.0D;
				double netWriteTotal = 0.0D;
				for(int i=2;i<names.length;i++){
					double theVal = Double.parseDouble(cols[i]);
					synchronized(netDetail){
						TimeSeries seriesRef = netDetailDataSet.getSeries(names[i]);
						if(seriesRef == null){
							seriesRef = new TimeSeries(names[i]);
							netDetailDataSet.addSeries(seriesRef);
							int seriesCount = netDetailDataSet.getSeriesCount();
							XYPlot xyplot = netDetail.getXYPlot(); 
							XYItemRenderer xyplotRenderer = xyplot.getRenderer();
							for(int j=0;j<seriesCount;j++){
								xyplotRenderer.setSeriesStroke(j, new BasicStroke(1.8f));
							} 
						}
						seriesRef.add(dateItem,theVal);
					}
					if(names[i].matches(".+read.+")){
						netReadTotal += theVal;
					}else{
						netWriteTotal += theVal;
					}
				}
				synchronized(netTotal){
					readTotalSeries.add(dateItem,netReadTotal);
					writeTotalSeries.add(dateItem,-netWriteTotal);
				}
				
			} catch (ParseException e1) {
				
				//e1.printStackTrace();
			}
		}
	}

}
