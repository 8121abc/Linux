package li.xiang.nmonanalyser.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class AgentSelectFrame extends JDialog implements ActionListener{
	private static final long serialVersionUID = 5831815104620262114L;
	
	private static AgentSelectFrame dialog;
	private static String targetIP = "";
	private static int targetPort = -1;
	
	final JTextField ipTxtField;
	final JTextField portTxtField;
	
	private AgentSelectFrame(Frame frame,
				Component locationComp,
				String title){
		
		super(frame,title,true);

		Container contentPanel = getContentPane();
		contentPanel.setLayout(new BorderLayout());
		
		JPanel northPanel = new JPanel(); //up
		northPanel.setPreferredSize(new Dimension(300,30));
		//northPanel.setBackground(Color.PINK); 
		contentPanel.add(northPanel,BorderLayout.PAGE_START);
		
		JPanel  southPanel = new JPanel();
		//southPanel.setBackground(Color.yellow);//down
		southPanel.setPreferredSize(new Dimension(300,10));
		contentPanel.add(southPanel,BorderLayout.PAGE_END);
		
		JPanel westPanel = new JPanel(); //left
		westPanel.setPreferredSize(new Dimension(20,300));
		//westPanel.setBackground(Color.WHITE); 
		contentPanel.add(westPanel,BorderLayout.LINE_START);	

		JPanel eastPanel = new JPanel(); //right
		eastPanel.setPreferredSize(new Dimension(20,200));
		//eastPanel.setBackground(Color.WHITE); 
		contentPanel.add(eastPanel,BorderLayout.LINE_END);

		JPanel centerPanel = new JPanel();
		//centerPanel.setBackground(Color.WHITE);//center
		GridLayout panelLayout = new GridLayout(0,2);
		panelLayout.setHgap(10);
		panelLayout.setVgap(10);
		centerPanel.setLayout(panelLayout); //2 columns
		contentPanel.add(centerPanel,BorderLayout.CENTER);
		
		JLabel ipLabel = new JLabel("Agent's IP Address:");
		centerPanel.add(ipLabel);
		ipTxtField = new JTextField();
		centerPanel.add(ipTxtField);
		
		JLabel portLabel = new JLabel("Agent's Listening Port:");
		centerPanel.add(portLabel);
		
		portTxtField = new JTextField();
		centerPanel.add(portTxtField);
		
		final JButton connectBtn = new JButton(" Connect ... ");
		connectBtn.setActionCommand("ConnectTo");
		connectBtn.addActionListener(this);
		this.getRootPane().setDefaultButton(connectBtn);
		centerPanel.add(connectBtn);
		
		final JButton cancelBtn = new JButton(" Cancel ");
		cancelBtn.setActionCommand("Cancel");
		cancelBtn.addActionListener(this);
		centerPanel.add(cancelBtn);
		
	}
	public static void showDiaglog(
				Component frameComp,
				Component locationComp,
				String title){
		int x,y;
		Frame frame = JOptionPane.getFrameForComponent(frameComp);
		dialog = new AgentSelectFrame(
				frame,
				locationComp, 
				title);
		//dialog.setLocationRelativeTo(locationComp);
		Point parentLocation = locationComp.getLocationOnScreen();
		Dimension parentSize = locationComp.getSize();
		Dimension dialogSize = dialog.getSize();
		if(parentSize.width > dialogSize.width){
			x = (parentSize.width-260)/2+parentLocation.x;
		}else{
			x = parentLocation.x;
		}
		if(parentSize.height > dialogSize.height ){
			y = (parentSize.height-350)/2+parentLocation.y;
		}else{
			y = parentLocation.y;
		}
		dialog.setSize(new Dimension(320,200));
		
		dialog.setLocation(x,y);
		dialog.requestFocus();
		dialog.setResizable(false);
		dialog.setVisible(true);
		
	}
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if(cmd.equals("Cancel")){
			targetIP = null;
			targetPort = 0;
			this.setVisible(false);
		}else if(cmd.equals("ConnectTo")){
			setTargetIP(ipTxtField.getText());
			try{
				setTargetPort(Integer.parseInt(portTxtField.getText()));
				this.setVisible(false);
			}catch(NumberFormatException numExcep){
				JOptionPane.showMessageDialog(dialog,
					    "Illegal port number ! ",
					    "Port Number Error.",
					    JOptionPane.ERROR_MESSAGE);
				portTxtField.setText("");
			}
		}
	}
	public static void setTargetIP(String targetIP) {
		AgentSelectFrame.targetIP = targetIP;
	}
	public static String getTargetIP() {
		return targetIP;
	}
	public static void setTargetPort(int targetPort) {
		AgentSelectFrame.targetPort = targetPort;
	}
	public static int getTargetPort() {
		return targetPort;
	}

}
