package li.xiang.nmonanalyser.agent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ConnectionHandler extends Thread{
	private final FIFOBuffer buffer;
	private final PrintWriter sender;
	private final BufferedReader receiver;
	private final PipeReader pipeReader;
	private final Socket connection;
	private final AgentConfiguration config;
	public ConnectionHandler(Socket connection,PipeReader reader) throws IOException{
		this.connection = connection; 
		buffer = new FIFOBuffer();
		sender = new PrintWriter(connection.getOutputStream());
		receiver = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		pipeReader = reader;
		config = AgentConfiguration.getConfig(true);
	}
	public void fillBuffer(String line){
		synchronized(buffer){
			buffer.put(line);
		}
	}
	private void sendConfigData(HashMap configData, String area,final PrintWriter sender){
		if(area.equals("ALL")){
			Iterator it = configData.entrySet().iterator();
			while(it.hasNext()){
				Map.Entry pairs = (Map.Entry)it.next();
				ArrayList value = (ArrayList)pairs.getValue();
				for(int i=0;i<value.size();i++){
					sender.println((String)value.get(i));
					sender.flush();
				}
			}
		}else{
			ArrayList value = (ArrayList)configData.get(area);
			if(value!=null){
				for(int i=0;i<value.size();i++){
					sender.println((String)value.get(i));
					sender.flush();
				}
			}
		}
	}
	public void close() throws IOException{
		pipeReader.deleteObserver(this);
		Thread.currentThread().interrupt();
		buffer.clearAll();
		sender.close();
		receiver.close();
	}
	public void run(){
		while(!Thread.interrupted()&&connection.isConnected()){
			try {
				if(receiver.ready()){
					String receCommand = receiver.readLine();
					String[] subCommand = receCommand.split("@");
					if(subCommand.length==2){
						if(subCommand[0].equals("CONFIGDATA")){
							sendConfigData(pipeReader.getConfigArea(),subCommand[1],sender);
						}
					}
				}
				sender.println(buffer.get());
				sender.flush();
			} catch (IOException e) {
			
				e.printStackTrace();
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
		}
		config.debug("Connection: Close or Thread close.");
	}
	
}
