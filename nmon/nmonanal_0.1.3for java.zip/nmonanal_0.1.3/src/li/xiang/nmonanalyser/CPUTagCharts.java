package li.xiang.nmonanalyser;

import java.awt.BasicStroke;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class CPUTagCharts implements NmonDataListener{
	private ArrayList cpuallColArray;
	private String cpuallColName;
	private final SimpleDateFormat formatter;
	private final JFreeChart[] charts;
	private final JFreeChart cpuallChart;
	private final JFreeChart cpuxxxChart;
	private final TimeSeriesCollection cpuallDataSet;
	private final TimeSeriesCollection cpuxxxDataSet;
	private final TimeSeries cpuallSeriesUser;
	private final TimeSeries cpuallSeriesSys;
	private final TimeSeries cpuallSeriesWait;
	
	public CPUTagCharts(){
		formatter  = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
		
		cpuxxxDataSet = new TimeSeriesCollection();
		cpuallDataSet = new TimeSeriesCollection();
		
		cpuallSeriesSys = new TimeSeries("sys%");
		cpuallSeriesUser = new TimeSeries("user%");
		cpuallSeriesWait = new TimeSeries("wait%");
		
		cpuallDataSet.addSeries(cpuallSeriesUser);
		cpuallDataSet.addSeries(cpuallSeriesSys);
		cpuallDataSet.addSeries(cpuallSeriesWait);
		
		ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
		
		cpuallChart = ChartFactory.createXYAreaChart(
				"CPU Total Usage",
				"",
				" [ Usage(%) ] ",
				cpuallDataSet,
				PlotOrientation.VERTICAL,
				true,
				false,
				false);
		
		cpuallChart.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot1 = cpuallChart.getXYPlot();
		xyplot1.setForegroundAlpha(0.6f);
		DateAxis domainAxis1 = new DateAxis("");
		domainAxis1.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:ss",Locale.US));
		domainAxis1.setLowerMargin(0.001D);
		domainAxis1.setUpperMargin(0.001D);
		xyplot1.setDomainAxis(domainAxis1);

		cpuxxxChart = ChartFactory.createTimeSeriesChart(
				"CPU Detail Usage",
				"",
				"[ User%+%Sys ]",
				cpuxxxDataSet,
				true,
				false,
				false);
		cpuxxxChart.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot2 = cpuxxxChart.getXYPlot();
		xyplot2.setForegroundAlpha(0.6f);
		DateAxis domainAxis2 = new DateAxis("");
		domainAxis2.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:mm:ss",Locale.US));
		domainAxis2.setLowerMargin(0.001D);
		domainAxis2.setUpperMargin(0.001D);
		xyplot2.setDomainAxis(domainAxis2);
		
		charts = new JFreeChart[2];
		charts[0] = cpuallChart;
		charts[1] = cpuxxxChart;
		
	}
	
	public void onDataLoad(LoadEventData e) {
		String line = e.getEventData();
		String[] cols = line.split(",");
		NmonDataLoader source = e.getEventSource();
		////Get the CPU_ALL tag data define from, if not data, do nothing and return. 
		
		if(cpuallColName == null){
			//cpuallColArray = (ArrayList)source.getConfigArea().get("CPU_ALL");
			cpuallColArray = (ArrayList)source.getConfigDataByTag("CPU_ALL");
			if(cpuallColArray!=null){
				cpuallColName = (String)cpuallColArray.get(0);
			}else{
				return;
			}
		}
		////If it's CPU_ALL tag's data, parse and add it to cpuallDataSet.
		if(cols[0].equals("CPU_ALL")){
			String[] names = cpuallColName.split(",");
			
			try {
				Date timestamp = formatter.parse(cols[1]);
				Millisecond dateItem = new Millisecond(timestamp);
				double userVal = 0.0D;
				double sysVal = 0.0D;
				double waitVal = 0.0D;
				for(int i=2;i<names.length;i++){
					if(names[i].equals("User%")){
						userVal = Double.parseDouble(cols[i]);
					}else if(names[i].equals("Sys%")){
						sysVal = Double.parseDouble(cols[i]);
					}else if(names[i].equals("Wait%")){
						waitVal = Double.parseDouble(cols[i]);
					}
				}
				synchronized(cpuallChart){
					cpuallSeriesUser.add(dateItem,userVal);
					cpuallSeriesSys.add(dateItem,(sysVal+userVal));
					cpuallSeriesWait.add(dateItem,(waitVal+sysVal+userVal));
				}
			} catch (ParseException e1) {
				System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : "+"==");
				System.out.println(line);
				System.exit(-1);
				//e1.printStackTrace();
			}
		////If it's CPUnnn tag's data, use CPU_ALL column define to parse it and add to cpuxxxDataSet.
		}else if(cols[0].matches("CPU\\d+")){
			String[] names = cpuallColName.split(",");
			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
			try {
				Date timestamp = formatter.parse(cols[1]);
				Millisecond dateItem = new Millisecond(timestamp);
				
				double userVal = 0.0D;
				double sysVal = 0.0D;
				synchronized(cpuxxxChart){
					TimeSeries seriesRef = cpuxxxDataSet.getSeries(cols[0]);
					if(seriesRef == null){
						seriesRef = new TimeSeries(cols[0]);
						cpuxxxDataSet.addSeries(seriesRef);
						int seriesCount = cpuxxxDataSet.getSeriesCount();
						XYPlot xyplot = charts[1].getXYPlot(); 
						XYItemRenderer xyplotRenderer = xyplot.getRenderer();
						for(int i=0;i<seriesCount;i++){
							xyplotRenderer.setSeriesStroke(i, new BasicStroke(1.8f));
						}
					}
				
					for(int i=2;i<cols.length;i++){
						if(names[i].equals("User%")){
							try{
								userVal = Double.parseDouble(cols[i+1]);
							}catch(Exception nan){
								userVal = 0.0D;
							}
						}else if(names[i].equals("Sys%")){
							try{
								sysVal = Double.parseDouble(cols[i]);
							}catch(Exception nan){
								sysVal = 0.0D;
							}
						}
					}
					seriesRef.add(dateItem,userVal+sysVal);
				}
			} catch (ParseException e1) {
				System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : "+"==");
				System.out.println(line);
				System.exit(-1);
			}
		}
	}

	public JFreeChart[] getCharts(){
		synchronized(charts){
			return charts;
		}
	}

}
