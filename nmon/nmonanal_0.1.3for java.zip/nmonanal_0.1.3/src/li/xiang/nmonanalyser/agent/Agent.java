package li.xiang.nmonanalyser.agent;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Agent implements Runnable{
	private final ServerSocket server;
	private final PipeReader pipeReader;
	private final AgentConfiguration config;
	public Agent() throws IOException{
		config = AgentConfiguration.getConfig(true);
		config.debug("----- Agent Configuration -----");
		config.debug("Nmon out pipe        :"+config.getPipeURI());
		config.debug("Agent listening port :"+config.getPort());
		config.debug("Maximum Connection   :"+config.getMaxConnection());
		config.debug("-------------------------------");
		server = new ServerSocket(config.getPort(),config.getMaxConnection());
		config.debug("Ageng Server Socket lisening on :"+config.getPort());
		File pipeFile = new File(config.getPipeURI());
		if(pipeFile.exists()){
			pipeReader = new PipeReader(pipeFile);
			Thread pipeReaderThread = new Thread(pipeReader);
			pipeReaderThread.start();
			config.debug("named pipe reader thread started.");
			
		}else{
			pipeReader = null;
			config.debug("named pipe: "+config.getPipeURI()+" didn't exists... agent abort.");
			System.exit(-1);
		}
	}
	public void run(){
		while(!Thread.interrupted()){
			try{
				Socket connection = server.accept();
				config.debug("[ "+connection.getInetAddress()+" ] connected.");
				ConnectionHandler handler =  new ConnectionHandler(connection,pipeReader);
				pipeReader.addObserver(handler);
				handler.start();
				
			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) throws IOException{
		Agent agent = new Agent();
		Thread agentThread = new Thread(agent);
		agentThread.start();
	}
}
