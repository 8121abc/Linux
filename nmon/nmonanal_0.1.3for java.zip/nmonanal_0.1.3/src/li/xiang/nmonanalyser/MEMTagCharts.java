package li.xiang.nmonanalyser;

import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class MEMTagCharts implements NmonDataListener{
	private ArrayList aaaColArray;
	private int platformName = -1;//-1, unknown platform; 0, AIX platform; 1, LINUX platform.
	private ArrayList memColArray;
	private ArrayList memnewColArray;
	private String memColName;
	private String memnewColName;
	private final SimpleDateFormat formatter;
	private final TimeSeriesCollection mem1DataSet; // memory free chart's dataset.
	private final TimeSeriesCollection mem2DataSet; // memory new(AIX) or paging space(LINUX) usage chart's dataset.
	private final JFreeChart[] charts;
	private final JFreeChart memChart1;
	private final JFreeChart memChart2;
	
	public MEMTagCharts(){
		formatter = new SimpleDateFormat("HH:mm:ss@dd-MMM-yyyy",Locale.US);
		mem1DataSet = new TimeSeriesCollection();
		mem2DataSet = new TimeSeriesCollection();
		
		ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
		memChart1 = ChartFactory.createXYAreaChart(
				 " Memory Free Size ",
				 "",
				 " [ Size (MB) ] ",
				 mem1DataSet,
				 PlotOrientation.VERTICAL,
				 true,
				 false,
				 false);
		memChart1.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot1 = memChart1.getXYPlot();
		DateAxis domainAxis1 = new DateAxis("");
		domainAxis1.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:mm:ss",Locale.US));
		domainAxis1.setLowerMargin(0.0);
		domainAxis1.setUpperMargin(0.0);
		xyplot1.setDomainAxis(domainAxis1);
		xyplot1.setForegroundAlpha(0.6f);
		
		memChart2 = ChartFactory.createXYAreaChart(
				"",
				"",
				" [ Size (MB) ] ",
				mem2DataSet,
				PlotOrientation.VERTICAL,
				true,
				false,
				false);
		memChart2.getTitle().setFont(new Font("Serif", Font.PLAIN, 16));
		XYPlot xyplot2 = memChart2.getXYPlot();
		DateAxis domainAxis2 = new DateAxis("");
		domainAxis2.setDateFormatOverride(new SimpleDateFormat("MM/dd HH:mm:ss",Locale.US));
		domainAxis2.setLowerMargin(0.0);
		domainAxis2.setUpperMargin(0.0);
		xyplot2.setDomainAxis(domainAxis2);
		xyplot2.setForegroundAlpha(0.6f);
		
		charts = new JFreeChart[2];
		charts[0] = memChart1;
		charts[1] = memChart2;
	}
	
	public void onDataLoad(LoadEventData e) {
		String line = e.getEventData();
		String[] cols = line.split(",");
		NmonDataLoader source = e.getEventSource();
		//Parse the AAA tag data, get the platform information, if it's AIX platform, get the MEMNEW tag's define.  
		if(platformName == -1){
			//aaaColArray = (ArrayList)source.getConfigArea().get("AAA");
			aaaColArray = (ArrayList)source.getConfigDataByTag("AAA");
			if(aaaColArray!=null){
				for(int i=0;i<aaaColArray.size();i++){
					String aaaLine = (String)aaaColArray.get(i);
					if(aaaLine.startsWith("AAA,OS,Linux")){
						platformName = 1;
						memChart2.setTitle("Paging in/out");
					}else if(aaaLine.startsWith("AAA,AIX")){
						platformName = 0;
						memChart2.setTitle("Memory New");
					}
				}
			}else{
				return ;
			}
		}else if((platformName == 0)&&(memnewColName == null)){
			//memnewColArray = (ArrayList)source.getConfigArea().get("MEMNEW");
			memnewColArray = (ArrayList)source.getConfigDataByTag("MEMNEW");
			if((memnewColArray!=null)){
				memnewColName = (String)memnewColArray.get(0);
			}else{
				return ;
			}
		}
		//Get the MEM tag's define.
		if(memColName == null){
			//memColArray = (ArrayList)source.getConfigArea().get("MEM");
			memColArray = (ArrayList)source.getConfigDataByTag("MEM");
			if(memColArray!=null){
				memColName = (String)memColArray.get(0);
			}else{
				return ;
			}
		}
		
		if(platformName == 0){ //Target system is AIX platform, parse the MEM, MEMNEW 's data.
			if(cols[0].equals("MEM")){  //AIX's MEM tag.
				String[] names = memColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					for(int i=2;i<names.length;i++){	// Get "Real free(MB)" and "Real total(MB)" columns form MEM tag.
						if(names[i].equals("Real free(MB)")){
							double theValue = Double.parseDouble(cols[i]);
							synchronized(mem1DataSet){
								TimeSeries seriesRef = mem1DataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									mem1DataSet.addSeries(seriesRef);
								}
								seriesRef.add(dateItem,theValue);
							}
						}else if(names[i].equals("Real total(MB)")){
							double theValue = Double.parseDouble(cols[i]);
							synchronized(mem1DataSet){
								TimeSeries seriesRef = mem1DataSet.getSeries(names[i]);
								if(seriesRef == null){
									seriesRef = new TimeSeries(names[i]);
									mem1DataSet.addSeries(seriesRef);
								}
								seriesRef.add(dateItem,theValue);
							}
						}
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row :  ==");
					System.out.println(line);
					System.exit(-1);
				}
			}else if(cols[0].equals("MEMNEW")){ //AIX's MEMNEW tag.
				String[] names = memnewColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double sysVal = 0.0D;
					double procVal = 0.0D;
					double fsVal = 0.0D;
					for(int i=names.length-1;i>1;i--){	// Get "Process%", "FScache%" and "System%" columns form MEM tag.
						if(names[i].equals("System%")){
							sysVal = Double.parseDouble(cols[i]);
							synchronized(mem2DataSet){
								TimeSeries seriesRef = mem2DataSet.getSeries(names[i]);
								if(seriesRef==null){
									seriesRef = new TimeSeries(names[i]);
									mem2DataSet.addSeries(seriesRef);
								}
								seriesRef.add(dateItem,sysVal);
							}
						}else if(names[i].equals("Process%")){
							procVal = Double.parseDouble(cols[i]);
							synchronized(mem2DataSet){
								TimeSeries seriesRef = mem2DataSet.getSeries(names[i]);
								if(seriesRef==null){
									seriesRef = new TimeSeries(names[i]);
									mem2DataSet.addSeries(seriesRef);
									
								}
								seriesRef.add(dateItem,procVal+sysVal+fsVal);
							}
						}else if(names[i].equals("FScache%")){
							fsVal = Double.parseDouble(cols[i]);
							synchronized(mem2DataSet){
								TimeSeries seriesRef = mem2DataSet.getSeries(names[i]);
								if(seriesRef==null){
									seriesRef = new TimeSeries(names[i]);
									mem2DataSet.addSeries(seriesRef);
								}
								seriesRef.add(dateItem,fsVal+sysVal);
							}
						}
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row : ==");
					System.out.println(line);
					System.exit(-1);
				}
				
			}
		}else if(platformName == 1){  // LINUX platform.
			
			if(cols[0].equals("MEM")){
				String[] names = memColName.split(",");
				try {
					Date timestamp = formatter.parse(cols[1]);
					Millisecond dateItem = new Millisecond(timestamp);
					double buffVal = 0.0D;
					double freeVal = 0.0D;
					for(int i=names.length-1;i>2;i--){
						 if(names[i].equals("buffers")){
							 double theVal = Double.parseDouble(cols[i]);
							 String seriesName = " File Buffers ";
							 synchronized(mem1DataSet){
								 TimeSeries seriesRef = mem1DataSet.getSeries(seriesName);
								 if(seriesRef==null){
									 seriesRef = new TimeSeries(seriesName);
									 mem1DataSet.addSeries(seriesRef);
								 }
								 buffVal = theVal;
								 seriesRef.add(dateItem,buffVal);
							 }
						 }else if(names[i].equals("memfree")){
							 double theVal = Double.parseDouble(cols[i]);
							 String seriesName = " Total Free (+File Buffers) ";
							 synchronized(mem1DataSet){
								 TimeSeries seriesRef = mem1DataSet.getSeries(seriesName);
								 if(seriesRef == null){
									 seriesRef = new TimeSeries(seriesName);
									 mem1DataSet.addSeries(seriesRef);
								 }
								 freeVal = theVal;
								 seriesRef.add(dateItem,freeVal+buffVal);
							 }
						 }else if(names[i].equals("swapfree")){
							 double theVal = Double.parseDouble(cols[i]);
							 String seriesName = " Paging Free ";
							 synchronized(mem2DataSet){
								 TimeSeries seriesRef = mem2DataSet.getSeries(seriesName);
								 if(seriesRef == null){
									 seriesRef = new TimeSeries(seriesName);
									 mem2DataSet.addSeries(seriesRef);
								 }
								 seriesRef.add(dateItem,theVal);
							 }
						 }else if(names[i].equals("swaptotal")){
							 double theVal = Double.parseDouble(cols[i]);
							 String seriesName = " Paging Total ";
							 synchronized(mem2DataSet){
								 TimeSeries seriesRef = mem2DataSet.getSeries(seriesName);
								 if(seriesRef==null){
									 seriesRef = new TimeSeries(seriesName);
									 mem2DataSet.addSeries(seriesRef);
								 }
								 seriesRef.add(dateItem,theVal);
							 }
						 }
					}
				} catch (ParseException e1) {
					System.out.println("== Fatal Error(Exit!): failed to parse the Date in row :  ==");
					System.out.println(line);
					System.exit(-1);
				}
			}
		}
		
	}

	public JFreeChart[] getCharts(){
		synchronized(charts){
			return charts;
		}
	}
	
}
